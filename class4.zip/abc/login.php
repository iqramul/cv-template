<html>
<head>
<title>LoginPage</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div id="frm">
<form action="process.php" method="post">
<p>
<label>Username:</label>
<input type="text" id="user" name="user"/>
</p>
<p>
<label>Password:</label>
<input type="password" id="pass" name="pass"/>
</p>
<p>
<input type="submit" id="btn" name="Login"/>
</p>


</form>
</div>


</body>
</html>